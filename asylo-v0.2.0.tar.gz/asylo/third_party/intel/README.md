This folder contains headers and and edl from the Intel SGX SDK. They are
verbatim from the 1.9 release.
